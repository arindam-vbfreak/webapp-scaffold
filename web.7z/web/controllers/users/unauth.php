<?php
    $page_title = "Unauthorized";
    $page = "users/unauth";
    $data = null;
    $showMessage = "";
    
    require partials("header");
    require view($page);    
    require partials("footer");
