<?php
    $page_title = "User login";
    $page = "users/login";
    $data = null;
    $showMessage = "";
    require partials("header");
    require addEventMapper();

    require view($page);


    function login(){
        global $showMessage;
        $return = tryLogin($_POST["email"],$_POST["password"]);
        if($return=="ok"){
            header("location: /home");
        }else{
            $showMessage = showMessage($return,"mt-3");
        }
        echo $showMessage;
    }
    require partials("footer");


