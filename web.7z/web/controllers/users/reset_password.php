<?php
    $page_title = "Reset Password";
    $page = "users/reset_password";
    $data = null;
    $showMessage = "";
    require addEventMapper();
    

    function change_password(){
        global $showMessage;
        if(db_query("update `users` set password=md5('{$_POST["password"]}') where email = '{$_POST["_reset_password"]}'")){
            $showMessage .= showMessage("Password changed successfully!");
        }
    }

    $data["users"] = db_query("select name,email from users where email='{$_SESSION["username"]}'");
    $data["message"] = $showMessage;

    require partials("header");
    require view($page);
    require partials("footer");


