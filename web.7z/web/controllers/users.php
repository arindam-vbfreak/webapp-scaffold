<?php
    $page_title = "Manage Users";
    $page = "users";
    $data = null;
    $showMessage = "";
    require addEventMapper();
    

    function create_user(){
        global $showMessage;
        if(db_query("INSERT INTO `users`(`email`, `password`, `name`, `role`) 
                VALUES ('{$_POST["email"]}',md5('12345'),'{$_POST["name"]}','{$_POST["role"]}')")){
                    $showMessage .= showMessage("User created successfully!");
                }
    }

    function block_user(){
        global $showMessage;
        if(db_query("update `users` set is_active=if(is_active=1,0,1) where email = '{$_POST["_block_user"]}'")){
            $showMessage .= showMessage("User deleted successfully!");
        }
    }

    function reset_password(){
        global $showMessage;
        if(db_query("update `users` set password=md5('12345') where email = '{$_POST["_reset_password"]}'")){
            $showMessage .= showMessage("Password reset successfully!");
        }
    }

    $data["users"] = db_query("select * from users");
    $data["message"] = $showMessage;

    require partials("header");
    require partials("nav");
    require view($page);
    require partials("footer");


