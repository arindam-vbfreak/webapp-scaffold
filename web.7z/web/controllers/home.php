<?php
    $page_title = "Home";
    $page = "home";
    
    require partials("header");
    require partials("nav");
    require view($page);
    require partials("footer");
