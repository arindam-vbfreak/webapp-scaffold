<?php
    $page_title = "Not Found";
    $page = "404";
    require view($page);
