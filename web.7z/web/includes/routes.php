<?php
    $public_routes = [
        '/login' => 'users/login',
        '/unauth' => 'users/unauth'
    ];

    $private_routes = [
        '/' => 'index',
        '/home' => 'home',
        '/index' => 'index',
        '/reset_password' => 'users/reset_password',
        '/users' => 'users'
    ];