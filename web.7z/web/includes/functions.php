<?php

    include "env.php";
    include "includes/connection.php";
    include "includes/routes.php";

    function run($route){
        global $public_routes;
        global $private_routes;

        if(array_key_exists($route, $public_routes)){
            require controller($route);
         }else{
            if(isLoggedIn()){
                require array_key_exists($route, $private_routes)?controller($route,true):controller("/404");
            }else{
                require array_key_exists($route, $private_routes)?controller("/unauth"):controller("/404");
            }
         }
    }

    function addEventMapper(){
        return "includes/misc.php";
    }

    function controller($path,$private=false){
        global $public_routes;
        global $private_routes;
        if($private){
            $part ="controllers/".$private_routes[$path].".php";
        }else{
            $part ="controllers/".$public_routes[$path].".php";
        }
        return $part;
    }

    function view($path){
        return "views/{$path}.view.php";
    }

    function partials($part){
        return "views/partials/$part.php";
    }

    function dependencies($part,$type){
        if($part==null) return false;
        $path = "views/dependencies/{$part}.{$type}";
        if(file_exists($path)){
            ?>
            <link rel="stylesheet" href="<?=$path?>">
            <?php
        }
    }

    function writeJS($script){
        return "<script>function showMessage(){
                    {$script}
                }</script>";
    }

    function ifRowEmpty($rows,$template){
        echo $rows->rowCount()==0?$template:"";
    }

    function showNotification($message,$title = "Information"){
        $showMessage = "$('#modalNotification #modalNotificationTitle').html('{$title}');";
        $showMessage .= "$('#modalNotification #modalNotificationBody').html('{$message}');";
        $showMessage .= "$('#modalNotification').modal('show');";
        return writeJS($showMessage);
    }

    function showMessage($message, $class = "",$target = "#message", $type = "primary"){
        $showMessage = "$('$target').html(\"<div class='alert alert-$type $class'>$message</div>\");";
        return writeJS($showMessage);
    }

    if(isset($_POST["logout"])){
        session_destroy();
    }
