<?php

    $database = $debug ? $development_settings["database"] : $production_settings["database"]; 
    $con = null;
    try {
        $con = getConnectionObject();
    } catch (Throwable $th) {
        $con = null;
    }

    function getConnectionObject(){
        global $database;
        $server = $database["server"];
        $port = $database["port"];
        $dbname= $database["dbname"];
        return new PDO("mysql:host=$server;port=$port;dbname=$dbname",$database["username"],$database["password"]);
    }

    function db_query($sql){
        global $con;
        if($con==null){
            return false;
        }else{
            return $con->query($sql);
        }
    }

    function tryLogin($email,$password,$setSession=true){
        $count = 0;
        $msg = "ok";
        foreach (db_query("select is_active,email,name,role from users where password=md5('$password') and email='$email'") as $row) {
            $count++;
            if($row["is_active"]==0){
                $msg = "User inactive";
            }else{
                if($setSession){
                    $_SESSION["username"]=$row["email"];
                    $_SESSION["name"]=$row["name"];
                    $_SESSION["role"]=$row["role"];
                }
            }
        }
        if($count==1){
            return $msg;
        }else{
            return "User does not exists or invalid credentials";
        }
    }
        
    function isLoggedIn(){
        return isset($_SESSION["username"]);
    }

