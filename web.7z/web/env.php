<?php
    $production_settings = [
        'database'=>[
            'server'=>'localhost',
            'port'=>'3306',
            'username'=>'root',
            'password'=>'',
            'dbname'=>'paite_dictionarydb'
        ]
    ];

    $development_settings = [
        'database'=>[
            'server'=>'localhost',
            'port'=>'3306',
            'username'=>'root',
            'password'=>'',
            'dbname'=>'paite_dictionarydb'
        ]
    ];

    $debug=isset($debug)?$debug:true;
