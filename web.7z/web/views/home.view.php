<div class="container mt-3">
    <div class="row text-center">
        <div class="col-sm-4">
            <div>
                Words
            </div>
        </div>
        <div class="col-sm-4">
            <div>
                Approvers 
            </div>
        </div>
        <div class="col-sm-4">
            Contributor
        </div>
    </div>
</div>