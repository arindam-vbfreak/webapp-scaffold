    <div class="row d-flex justify-content-center" style="align-items: center;">
        <div class="col-sm-6 border shadow-sm">
            <div class="p-3">
            <?php
                foreach ($data["users"] as $user) {
                    ?>
                        <h6>Welcome, <?=$user["name"];?>!</h6>
                        <div class="text-muted mb-3">Here you can change your password.</div>
                        <div>
                            <input type="text" name="password" class="form-control" placeholder="Enter a new password...">
                        </div>
                        <div>
                            <button confirmation="Are you sure?" type="submit" title='User' 
                                class="btn btn-sm btn-success mt-3 btn-block" type="submit" value="<?=$user["email"];?>"
                                name="_change_password">Change Password</button>
                        </div>
                    <?php
                }
            ?>
            </div>
        </div>
    </div>
