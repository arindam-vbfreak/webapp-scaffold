<div class="container text-center pt-5">
    <h5>You do not have access to view this page.</h5>
    <div class="text-muted">
        To login with a different credentials click <a href="/login">here</a>.
    </div>
</div>