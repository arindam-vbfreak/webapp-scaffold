<div class="container">
    <div class="row d-flex justify-content-center mt-5">
        <div class="col-sm-12 col-md-5 border shadow-sm">
            <div class="p-3">
                <h6>Welcome, User!</h6>
                <div class="text-muted mb-3">Enter your credentials to login.</div>
                <div class="text-muted mb-3">
                    Email:
                    <input type="text" name="email" class="form-control" placeholder="Enter your email...">
                </div>
                <div class="text-muted mb-3">
                    Password:
                    <input type="text" name="password" class="form-control" placeholder="Enter your password...">
                </div>
                <div>
                    <button type="submit" title='User' 
                        class="btn btn-sm btn-success mt-3 btn-block" type="submit"
                        name="_login">Login</button>
                        <span id="message"></span>
                </div>
            </div>
        </div>
    </div>
</div>