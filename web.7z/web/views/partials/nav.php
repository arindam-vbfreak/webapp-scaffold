<nav class="bg-dark d-flex justify-content-between shadow px-3 py-1">
  <a class="navbar-brand text-white" href="/home">Paite Dictionary</a>
  <div class="text-muted d-flex align-items-center">
  <span class="fa fa-user mr-2"></span> <span><?=$_SESSION["name"]?></span>
  </div>
</nav>
<div class="modal fade" id="modalNotification" tabindex="-1">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalNotificationLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modalNotificationBody">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>