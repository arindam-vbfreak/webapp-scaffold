<?php
    require partials("scripts");
    dependencies($page,"js");
?>
<script>
    if(typeof showMessage !== undefined) showMessage();
</script>
</form>
<footer class="bg-dark text-muted fixed-bottom p-2">
    <div>
        Designed with <span class="fa text-danger fa-heart"></span> by Technowell Services Pvt Ltd.    
    </div>
</footer>
</body>
</html>